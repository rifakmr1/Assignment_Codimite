<?php

require_once 'DBConnection.php';

class TodoAPI
{
    private $connection;

    public function __construct()
    {
        $db = new DBConnection();
        $this->connection = $db->getConnection();
    }

    public function addTodo($task)
    {
        $query = "INSERT INTO todos (task) VALUES ('$task')";
        $result = $this->connection->query($query);
        return $result;
    }

    public function removeTodo($id)
    {
        $query = "DELETE FROM todos WHERE id = $id";
        $result = $this->connection->query($query);
        return $result;
    }

    public function listTodos()
    {
        $query = "SELECT * FROM todos";
        $result = $this->connection->query($query);
        $todos = array();
        while ($row = $result->fetch_assoc()) {
            $todos[] = $row;
        }
        return $todos;
    }
}
