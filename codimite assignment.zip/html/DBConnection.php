<?php

require_once 'vendor/autoload.php';

use Google\Cloud\Sql\SqlAdminClient;

class DBConnection
{
    private $sqlAdminClient;
    private $instance;
    private $connection;

    public function __construct()
    {
        // Create an instance of the SQL Admin Client
        $this->sqlAdminClient = new SqlAdminClient();

        // Replace "project-id" and "instance-name" with your actual project ID and instance name
        $this->instance = $this->sqlAdminClient->instance("codemite-gcp-assignment", "example-instance");

        // Create a new connection
        $this->connection = $this->instance->connect();
    }

    public function getConnection()
    {
        return $this->connection;
    }
}
